using CourseManagement.Application.DTOs;
using CourseManagement.Application.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace CourseManagement.API.Controllers;

[Authorize]
[ApiController]
[Route("api/[controller]")]
public class LessonsController : ControllerBase
{
    private readonly ILessonService _lessonService;

    public LessonsController(ILessonService lessonService)
    {
        _lessonService = lessonService;
    }

    [HttpGet("{id}")]
    public async Task<ActionResult<LessonDto>> GetById(Guid id)
    {
        var lesson = await _lessonService.GetByIdAsync(id);
        if (lesson == null) return NotFound();
        return Ok(lesson);
    }

    [HttpPost]
    public async Task<ActionResult<LessonDto>> Create([FromBody] CreateLessonDto createDto)
    {
        try
        {
            var lesson = await _lessonService.CreateAsync(createDto);
            return CreatedAtAction(nameof(GetById), new { id = lesson.Id }, lesson);
        }
        catch (InvalidOperationException ex)
        {
            return BadRequest(new { message = ex.Message });
        }
    }

    [HttpPut("{id}")]
    public async Task<ActionResult<LessonDto>> Update(Guid id, [FromBody] UpdateLessonDto updateDto)
    {
        try
        {
            var lesson = await _lessonService.UpdateAsync(id, updateDto);
            return Ok(lesson);
        }
        catch (InvalidOperationException ex)
        {
            return BadRequest(new { message = ex.Message });
        }
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(Guid id)
    {
        try
        {
            await _lessonService.DeleteAsync(id);
            return NoContent();
        }
        catch (InvalidOperationException ex)
        {
            return NotFound(new { message = ex.Message });
        }
    }

    [HttpPost("{id}/reorder")]
    public async Task<IActionResult> Reorder(Guid id, [FromBody] ReorderLessonDto reorderDto)
    {
        try
        {
            // Note: The ReorderLessonDto we received might just contain Direction, 
            // but the Service needs courseId + lessonId.
            // We need to fetch the lesson first to get the course ID, or trust the client to send it.
            // Our Service method signature is: ReorderAsync(Guid courseId, Guid lessonId, string direction)
            // But we only have lessonId from route. Let's look up the lesson first.
            var lesson = await _lessonService.GetByIdAsync(id);
            if (lesson == null) return NotFound();

            await _lessonService.ReorderAsync(lesson.CourseId, id, reorderDto.Direction);
            return Ok(new { message = "Lesson reordered successfully" });
        }
        catch (InvalidOperationException ex)
        {
            return BadRequest(new { message = ex.Message });
        }
    }
}
