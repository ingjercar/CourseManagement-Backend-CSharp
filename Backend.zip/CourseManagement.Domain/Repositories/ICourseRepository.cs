using CourseManagement.Domain.Entities;

namespace CourseManagement.Domain.Repositories;

public interface ICourseRepository
{
    Task<Course?> GetByIdAsync(Guid id);
    Task<Course?> GetByIdWithLessonsAsync(Guid id);
    Task<IEnumerable<Course>> GetAllAsync();
    Task<(IEnumerable<Course> Courses, int TotalCount)> SearchAsync(
        string? searchTerm, 
        CourseStatus? status, 
        int page, 
        int pageSize);
    Task<Course> AddAsync(Course course);
    Task UpdateAsync(Course course);
    Task DeleteAsync(Course course);
    Task<bool> ExistsAsync(Guid id);
}
