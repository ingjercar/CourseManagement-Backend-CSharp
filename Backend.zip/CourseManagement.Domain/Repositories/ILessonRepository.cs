using CourseManagement.Domain.Entities;

namespace CourseManagement.Domain.Repositories;

public interface ILessonRepository
{
    Task<Lesson?> GetByIdAsync(Guid id);
    Task<IEnumerable<Lesson>> GetByCourseIdAsync(Guid courseId);
    Task<Lesson> AddAsync(Lesson lesson);
    Task UpdateAsync(Lesson lesson);
    Task DeleteAsync(Lesson lesson);
    Task<bool> ExistsWithOrderAsync(Guid courseId, int order, Guid? excludeLessonId = null);
    Task<int> GetMaxOrderByCourseIdAsync(Guid courseId);
}
