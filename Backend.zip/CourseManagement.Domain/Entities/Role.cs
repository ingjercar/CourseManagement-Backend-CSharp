using Microsoft.AspNetCore.Identity;

namespace CourseManagement.Domain.Entities;

public class Role : IdentityRole
{
}
