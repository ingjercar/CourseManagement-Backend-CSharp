using CourseManagement.Domain.Common;

namespace CourseManagement.Domain.Entities;

public enum CourseStatus
{
    Draft,
    Published
}

public class Course : BaseEntity
{
    public string Title { get; set; } = string.Empty;
    public CourseStatus Status { get; set; }
    
    public virtual ICollection<Lesson> Lessons { get; set; } = new List<Lesson>();

    public Course()
    {
        Status = CourseStatus.Draft;
    }
    
    public bool CanPublish()
    {
        return Lessons.Any(l => !l.IsDeleted);
    }

    public void Publish()
    {
        if (!CanPublish())
        {
            throw new InvalidOperationException("Cannot publish a course without active lessons");
        }
        Status = CourseStatus.Published;
        UpdatedAt = DateTime.UtcNow;
    }

    public void Unpublish()
    {
        Status = CourseStatus.Draft;
        UpdatedAt = DateTime.UtcNow;
    }

    public void SoftDelete()
    {
        IsDeleted = true;
        UpdatedAt = DateTime.UtcNow;
    }
}
