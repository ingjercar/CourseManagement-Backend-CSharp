using CourseManagement.Domain.Entities;

namespace CourseManagement.Tests;

public class CourseEntityTests
{
    [Fact]
    public void PublishCourse_WithLessons_ShouldSucceed()
    {
        // Arrange
        var course = new Course { Title = "Test Course" };
        course.Lessons.Add(new Lesson { Title = "Lesson 1", Order = 1 });

        // Act
        course.Publish();

        // Assert
        Assert.Equal(CourseStatus.Published, course.Status);
    }

    [Fact]
    public void PublishCourse_WithoutLessons_ShouldFail()
    {
        // Arrange
        var course = new Course { Title = "Test Course" };

        // Act & Assert
        Assert.Throws<InvalidOperationException>(() => course.Publish());
    }

    [Fact]
    public void DeleteCourse_ShouldBeSoftDelete()
    {
        // Arrange
        var course = new Course { Title = "Test Course" };

        // Act
        course.SoftDelete();

        // Assert
        Assert.True(course.IsDeleted);
        Assert.NotNull(course.UpdatedAt);
    }
}
