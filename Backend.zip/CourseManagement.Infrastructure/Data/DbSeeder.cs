using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using CourseManagement.Domain.Entities;

namespace CourseManagement.Infrastructure.Data;

public static class DbSeeder
{
    public static async Task SeedAsync(IServiceProvider serviceProvider)
    {
        var userManager = serviceProvider.GetRequiredService<UserManager<User>>();
        var logger = serviceProvider.GetRequiredService<ILogger<ApplicationDbContext>>();

        logger.LogInformation("=== Starting Database Seeding ===");

        // Check if test user already exists
        logger.LogInformation("Checking if test user (test@example.com) already exists...");
        var testUser = await userManager.FindByEmailAsync("test@example.com");
        
        if (testUser == null)
        {
            logger.LogInformation("Test user does not exist. Creating new user...");
            
            testUser = new User
            {
                UserName = "testuser",
                Email = "test@example.com",
                EmailConfirmed = true
            };

            logger.LogInformation("Attempting to create user with UserName: {UserName}, Email: {Email}", 
                testUser.UserName, testUser.Email);

            var result = await userManager.CreateAsync(testUser, "Test123!");

            if (result.Succeeded)
            {
                logger.LogInformation("✓ Test user created successfully! UserId: {UserId}", testUser.Id);
            }
            else
            {
                logger.LogError("✗ Failed to create test user. Errors: {Errors}", 
                    string.Join(", ", result.Errors.Select(e => $"{e.Code}: {e.Description}")));
                throw new Exception($"Failed to create test user: {string.Join(", ", result.Errors.Select(e => e.Description))}");
            }
        }
        else
        {
            logger.LogInformation("✓ Test user already exists. UserId: {UserId}, UserName: {UserName}", 
                testUser.Id, testUser.UserName);
        }

        logger.LogInformation("=== Database Seeding Completed ===");
    }
}
