// TalentoPlus.Api/Controllers/EmployeeController.cs


using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using TalentoPlus.Application.DTOs;
using TalentoPlus.Application.Interfaces;
using TalentoPlus.Application.Services;
using TalentoPlus.Domain.Entities;
using TalentoPlus.Domain.IRepositories;

[ApiController]
[Route("api/[controller]")]
public class EmployeeController : ControllerBase
{
    private readonly IEmployeeService _service;
    private readonly IEmployeeRepository _repo;
    private readonly IEmployeeImportService _importService;
    private readonly IAIService _AIService;

    public EmployeeController(IEmployeeService service, IEmployeeRepository repo, IEmployeeImportService importService,  IAIService AIService)
    {
        _AIService = AIService;
        _importService = importService;
        _service = service;
        _repo = repo;
    }

    [HttpGet]
    [AllowAnonymous]
    public async Task<IActionResult> GetAll() =>
        Ok(await _service.GetAllAsync());

    [HttpGet("{id}")]
    [Authorize]
    public async Task<IActionResult> Get(int id)
    {
        var callerIdStr = User.FindFirst("id")?.Value;
        int.TryParse(callerIdStr, out var callerId);

        var charge = User.FindFirst("charge")?.Value ?? "";
        var departmentName = User.FindFirst("departmentName")?.Value ?? "";

        // Si no es admin RRHH y trata de ver otro id -> Forbidden
        if (!(charge == "Administrador" && departmentName == "Recursos Humanos") && callerId != id)
            return Forbid();

        var result = await _service.GetByIdAsync(id);
        return result == null ? NotFound() : Ok(result);
    }

    [HttpPost]
    [Authorize]
    public async Task<IActionResult> Create(EmployeeDto dto)
    {
        var charge = User.FindFirst("charge")?.Value ?? "";
        var departmentName = User.FindFirst("departmentName")?.Value ?? "";
        if (!(charge == "Administrador" && departmentName == "Recursos Humanos"))
            return Forbid();

        var created = await _service.CreateAsync(dto);
        return Ok(created);
    }

    [HttpPut("{id}")]
    [Authorize]
    public async Task<IActionResult> Update(int id, EmployeeDto dto)
    {
        var charge = User.FindFirst("charge")?.Value ?? "";
        var departmentName = User.FindFirst("departmentName")?.Value ?? "";
        if (!(charge == "Administrador" && departmentName == "Recursos Humanos"))
            return Forbid();

        var result = await _service.UpdateAsync(id, dto);
        return result == null ? NotFound() : Ok(result);
    }

    [HttpDelete("{id}")]
    [Authorize]
    public async Task<IActionResult> Delete(int id)
    {
        var charge = User.FindFirst("charge")?.Value ?? "";
        var departmentName = User.FindFirst("departmentName")?.Value ?? "";
        if (!(charge == "Administrador" && departmentName == "Recursos Humanos"))
            return Forbid();

        var ok = await _service.DeleteAsync(id);
        return ok ? Ok() : NotFound();
    }

    // Endpoint para que el empleado logueado descargue su propio PDF (hoja de vida)
    [HttpGet("{id}/resume")]
    [Authorize]
    public async Task<IActionResult> DownloadResume(int id, [FromServices] IPdfService pdfService)
    {
        var callerIdStr = User.FindFirst("id")?.Value;
        int.TryParse(callerIdStr, out var callerId);

        var charge = User.FindFirst("charge")?.Value ?? "";
        var departmentName = User.FindFirst("departmentName")?.Value ?? "";
        if (!(charge == "Administrador" && departmentName == "Recursos Humanos") && callerId != id)
            return Forbid();

        var employee = await _repo.GetByIdAsync(id);
        if (employee == null) return NotFound();

        var bytes = pdfService.GenerateResume(employee);
        return File(bytes, "application/pdf", $"{employee.Name}_{employee.LastName}_Resume.pdf");
    }
    [HttpPost("import-excel")]
    public async Task<IActionResult> ImportExcel(IFormFile file)
    {
        if (file == null || file.Length == 0)
            return BadRequest("Debe subir un archivo .xlsx");

        using var stream = file.OpenReadStream();
        var result = await _importService.ImportFromExcelAsync(stream);

        return Ok(new {
            message = $"Empleados importados: {result.Count}",
            data = result
        });
    }
    [HttpGet("dashboard")]
    public async Task<IActionResult> GetDashboard()
    {
        var all = await _service.GetAllAsync();

        var total = all.Count();
        var vacaciones = all.Count(e => e.Status == "Vacaciones");
        var activos = all.Count(e => e.Status == "Activo");

        return Ok(new {
            totalEmpleados = total,
            empleadosVacaciones = vacaciones,
            empleadosActivos = activos
        });
    }
    public class IAQueryRequest 
    {
        public string Pregunta { get; set; } = string.Empty;
    }

    [HttpPost("query")]
    public async Task<IActionResult> QueryIA([FromBody] IAQueryRequest req)
    {
        var employees = await _service.GetAllAsync();

        // Convertimos los datos a una base tipo RAG simple
        var data = System.Text.Json.JsonSerializer.Serialize(employees);

        string prompt = $@"
Eres un analista de datos de RRHH. 
Responde SOLO usando la siguiente información del sistema:

{data}

Pregunta del usuario:
{req.Pregunta}
";

        string respuesta = await _AIService.GetCompletionAsync(prompt);

        return Ok(new { respuesta });
    }



}
