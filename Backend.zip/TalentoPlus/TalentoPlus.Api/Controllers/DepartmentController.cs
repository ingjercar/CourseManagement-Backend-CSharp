// TalentoPlus.Api/Controllers/DepartmentController.cs

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

[ApiController]
[Route("api/[controller]")]
public class DepartmentController : ControllerBase
{
    private static readonly string[] DefaultDepartments = new[]
    {
        "Recursos Humanos","Ventas","Logística","Marketing","Contabilidad","Operaciones","Tecnología"
    };

    [HttpGet]
    [AllowAnonymous]
    public IActionResult GetAll() => Ok(DefaultDepartments);
}