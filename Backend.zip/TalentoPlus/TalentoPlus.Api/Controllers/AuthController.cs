// TalentoPlus.Api/Controllers/AuthController.cs
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using TalentoPlus.Application.Services;
using TalentoPlus.Application.Interfaces;
using TalentoPlus.Application.DTOs;
using TalentoPlus.Domain.Entities;
using TalentoPlus.Domain.IRepositories;

[ApiController]
[Route("api/[controller]")]
public class AuthController : ControllerBase
{
    private readonly IAuthService _authService;
    private readonly ITokenService _tokenService;
    private readonly IEmailService _emailService;
    private readonly IEmployeeRepository _employeeRepo;

    public AuthController(IAuthService authService, ITokenService tokenService,
                          IEmailService emailService, IEmployeeRepository employeeRepo)
    {
        _authService = authService;
        _tokenService = tokenService;
        _emailService = emailService;
        _employeeRepo = employeeRepo;
    }

    [HttpPost("register")]
    public async Task<IActionResult> Register([FromBody] EmployeeDto dto, [FromQuery] string password)
    {
        if (string.IsNullOrWhiteSpace(password)) return BadRequest("password required");

        // Map DTO -> Entity (simple)
        var employee = new Employee
        {
            Document = dto.Document,
            Name = dto.Name,
            LastName = dto.LastName,
            BirthDate = dto.BirthDate,
            Address = dto.Address,
            Email = dto.Email,
            Phone = dto.Phone,
            Charge = dto.Charge,
            Salary = dto.Salary,
            StartDate = dto.StartDate,
            Status = dto.Status,
            ProfessionalPorfile = dto.ProfessionalPorfile,
            EducationLevel = dto.EducationLevel,
            DepartmentId = dto.DepartmentId
        };

        var created = await _authService.RegisterAsync(employee, password);
        if (created == null) return Conflict("Ya existe un empleado con ese documento");

        // Send email (fire-and-forget pattern is ok here but we await)
        await _emailService.SendRegistrationEmailAsync($"{created.Name} {created.LastName}", created.Email);

        return Ok(new { message = "Registrado con éxito" });
    }

    [HttpPost("login")]
    public async Task<IActionResult> Login([FromBody] LoginRequest req)
    {
        var (employee, success) = await _authService.ValidateCredentialsAsync(req.Document, req.Email, req.Password);
        if (!success || employee == null) return Unauthorized();

        var token = _tokenService.GenerateAccessToken(employee);

        // Optionally generate & save refresh token here
        employee.RefreshToken = Guid.NewGuid().ToString(); // simple refresh token
        employee.RefreshTokenExpiry = DateTime.UtcNow.AddDays(7);
        _employeeRepo.Update(employee);
        await _employeeRepo.SaveChangesAsync();

        return Ok(new { token, refreshToken = employee.RefreshToken });
    }

    [Authorize]
    [HttpPost("logout")]
    public async Task<IActionResult> Logout()
    {
        var idClaim = User.FindFirst("id")?.Value;
        if (!int.TryParse(idClaim, out var id)) return Unauthorized();

        var emp = await _employeeRepo.GetByIdAsync(id);
        if (emp == null) return Unauthorized();
        await _authService.LogoutAsync(emp);
        return Ok();
    }

    [Authorize]
    [HttpGet("me")]
    public async Task<IActionResult> Me()
    {
        var idClaim = User.FindFirst("id")?.Value;
        if (!int.TryParse(idClaim, out var id)) return Unauthorized();

        var emp = await _employeeRepo.GetByIdAsync(id);
        if (emp == null) return NotFound();

        // Map to DTO
        var dto = new EmployeeDto
        {
            Id = emp.Id,
            Document = emp.Document,
            Name = emp.Name,
            LastName = emp.LastName,
            BirthDate = emp.BirthDate,
            Address = emp.Address,
            Email = emp.Email,
            Phone = emp.Phone,
            Charge = emp.Charge,
            Salary = emp.Salary,
            StartDate = emp.StartDate,
            Status = emp.Status,
            ProfessionalPorfile = emp.ProfessionalPorfile,
            EducationLevel = emp.EducationLevel,
            DepartmentId = emp.DepartmentId
        };

        return Ok(dto);
    }
}

public record LoginRequest(string Document, string Email, string Password);
