using TalentoPlus.Application.DTOs;

public interface IEmployeeImportService
{
    Task<List<EmployeeDto>> ImportFromExcelAsync(Stream excelFile);
}