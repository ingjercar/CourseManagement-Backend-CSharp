public interface IAIService
{
    Task<string> GetCompletionAsync(string prompt);
}