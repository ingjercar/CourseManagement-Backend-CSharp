namespace TalentoPlus.Application.DTOs;

public class EmployeeDto
{
    public int Id { get; set; }
    public string Document { get; set; }
    public string Name { get; set; }
    public string LastName { get; set; }
    public DateOnly BirthDate { get; set; }
    public string Address { get; set; }
    public string Email { get; set; }
    public string Phone { get; set; }
    public string Charge { get; set; }
    public double Salary { get; set; }
    public DateOnly StartDate { get; set; }
    public string Status { get; set; }
    public string ProfessionalPorfile { get; set; }
    public string EducationLevel { get; set; }
    public int DepartmentId { get; set; }
}