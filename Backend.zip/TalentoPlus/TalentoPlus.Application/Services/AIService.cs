using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
using Microsoft.Extensions.Configuration;

public class AIService : IAIService
{
    private readonly HttpClient _http;

    public AIService(HttpClient http, IConfiguration _config)
    {
        _http = http;
        _http.DefaultRequestHeaders.Authorization =
            new AuthenticationHeaderValue("Bearer", _config["OpenAI:ApiKey"]);
    }

    public async Task<string> GetCompletionAsync(string prompt)
    {
        var response = await _http.PostAsJsonAsync(
            "https://api.openai.com/v1/chat/completions",
            new {
                model = "gpt-4o-mini",
                messages = new[] {
                    new { role = "user", content = prompt }
                }
            });

        var json = await response.Content.ReadFromJsonAsync<JsonElement>();
        return json.GetProperty("choices")[0]
            .GetProperty("message")
            .GetProperty("content")
            .GetString()!;
    }
}