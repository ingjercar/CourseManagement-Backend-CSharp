using TalentoPlus.Application.DTOs;
using TalentoPlus.Application.Interfaces;
using TalentoPlus.Domain.Entities;
using TalentoPlus.Domain.IRepositories;

namespace TalentoPlus.Application.Services;

public class EmployeeService : IEmployeeService
{
    private readonly IEmployeeRepository _repo;

    public EmployeeService(IEmployeeRepository repo)
    {
        _repo = repo;
    }

    public async Task<IEnumerable<EmployeeDto>> GetAllAsync() =>
        (await _repo.GetAllAsync()).Select(MapToDto);

    public async Task<EmployeeDto?> GetByIdAsync(int id)
    {
        var emp = await _repo.GetByIdAsync(id);
        return emp == null ? null : MapToDto(emp);
    }

    public async Task<EmployeeDto> CreateAsync(EmployeeDto dto)
    {
        var emp = MapToEntity(dto);
        await _repo.AddAsync(emp);
        await _repo.SaveChangesAsync();
        return MapToDto(emp);
    }

    public async Task<EmployeeDto> UpdateAsync(int id, EmployeeDto dto)
    {
        var emp = await _repo.GetByIdAsync(id);
        if (emp == null) return null;

        emp.Document = dto.Document;
        emp.Name = dto.Name;
        emp.LastName = dto.LastName;
        emp.BirthDate = dto.BirthDate;
        emp.Address = dto.Address;
        emp.Email = dto.Email;
        emp.Phone = dto.Phone;
        emp.Charge = dto.Charge;
        emp.Salary = dto.Salary;
        emp.StartDate = dto.StartDate;
        emp.Status = dto.Status;
        emp.ProfessionalPorfile = dto.ProfessionalPorfile;
        emp.EducationLevel = dto.EducationLevel;
        emp.DepartmentId = dto.DepartmentId;

        _repo.Update(emp);
        await _repo.SaveChangesAsync();

        return MapToDto(emp);
    }

    public async Task<bool> DeleteAsync(int id)
    {
        var emp = await _repo.GetByIdAsync(id);
        if (emp == null) return false;

        _repo.Delete(emp);
        await _repo.SaveChangesAsync();
        return true;
    }

    private static EmployeeDto MapToDto(Employee e) => new()
    {
        Id = e.Id,
        Document = e.Document,
        Name = e.Name,
        LastName = e.LastName,
        BirthDate = e.BirthDate,
        Address = e.Address,
        Email = e.Email,
        Phone = e.Phone,
        Charge = e.Charge,
        Salary = e.Salary,
        StartDate = e.StartDate,
        Status = e.Status,
        ProfessionalPorfile = e.ProfessionalPorfile,
        EducationLevel = e.EducationLevel,
        DepartmentId = e.DepartmentId
    };

    private static Employee MapToEntity(EmployeeDto e) => new()
    {
        Id = e.Id,
        Document = e.Document,
        Name = e.Name,
        LastName = e.LastName,
        BirthDate = e.BirthDate,
        Address = e.Address,
        Email = e.Email,
        Phone = e.Phone,
        Charge = e.Charge,
        Salary = e.Salary,
        StartDate = e.StartDate,
        Status = e.Status,
        ProfessionalPorfile = e.ProfessionalPorfile,
        EducationLevel = e.EducationLevel,
        DepartmentId = e.DepartmentId
    };
}
