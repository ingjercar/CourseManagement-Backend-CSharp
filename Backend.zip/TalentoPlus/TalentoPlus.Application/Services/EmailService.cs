// TalentoPlus.Application/Services/EmailService.cs
using MailKit.Net.Smtp;
using Microsoft.Extensions.Options;
using MimeKit;
using System.Threading.Tasks;

public class SmtpOptions
{
    public string Host { get; set; } = "";
    public int Port { get; set; }
    public string User { get; set; } = "";
    public string Pass { get; set; } = "";
    public string FromName { get; set; } = "";
    public string FromEmail { get; set; } = "";
}

public interface IEmailService
{
    Task SendRegistrationEmailAsync(string toName, string toEmail);
}

public class EmailService : IEmailService
{
    private readonly SmtpOptions _opts;
    public EmailService(IOptions<SmtpOptions> opts) => _opts = opts.Value;

    public async Task SendRegistrationEmailAsync(string toName, string toEmail)
    {
        var message = new MimeMessage();
        message.From.Add(new MailboxAddress(_opts.FromName, _opts.FromEmail));
        message.To.Add(new MailboxAddress(toName, toEmail));
        message.Subject = "Registro exitoso - TalentoPlus";

        var body = new BodyBuilder
        {
            HtmlBody = $"<p>Hola {toName},</p><p>Tu registro como empleado en TalentoPlus fue exitoso.</p><p>Saludos,<br/>Equipo TalentoPlus</p>"
        };

        message.Body = body.ToMessageBody();

        using var client = new SmtpClient();
        await client.ConnectAsync(_opts.Host, _opts.Port, MailKit.Security.SecureSocketOptions.StartTls);
        await client.AuthenticateAsync(_opts.User, _opts.Pass);
        await client.SendAsync(message);
        await client.DisconnectAsync(true);
    }
}