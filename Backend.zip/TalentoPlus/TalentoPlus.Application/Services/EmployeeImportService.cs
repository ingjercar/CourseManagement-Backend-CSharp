// TalentoPlus.Application/Services/EmployeeImportService.cs
using OfficeOpenXml;
using System.Globalization;
using TalentoPlus.Application.DTOs;
using TalentoPlus.Application.Interfaces;
using TalentoPlus.Domain.Entities;
using TalentoPlus.Domain.IRepositories;

namespace TalentoPlus.Application.Services;

public class EmployeeImportService : IEmployeeImportService
{
    private readonly IEmployeeService _employeeService;
    private readonly IDepartmentRepository _departmentRepo;

    private static readonly string[] AllowedDepartments =
    {
        "Recursos Humanos","Ventas","Logística","Marketing",
        "Contabilidad","Operaciones","Tecnología"
    };

    public EmployeeImportService(IEmployeeService employeeService, IDepartmentRepository departmentRepo)
    {
        _employeeService = employeeService;
        _departmentRepo = departmentRepo;
        ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
    }

    public async Task<List<EmployeeDto>> ImportFromExcelAsync(Stream excelFile)
    {
        var imported = new List<EmployeeDto>();
        using var package = new ExcelPackage(excelFile);
        var ws = package.Workbook.Worksheets[0];
        var rows = ws.Dimension?.Rows ?? 0;
        if (rows < 2) return imported;

        for (int row = 2; row <= rows; row++)
        {
            string deptName = ws.Cells[row, 14].Text?.Trim() ?? "";

            if (!AllowedDepartments.Contains(deptName))
                throw new Exception($"Departamento inválido en fila {row}: '{deptName}'");

            var department = await _departmentRepo.GetByNameAsync(deptName);
            if (department == null)
                throw new Exception($"El departamento '{deptName}' no existe en BD. Ejecuta el seed.");

            var dto = new EmployeeDto
            {
                Document = ws.Cells[row, 1].Text.Trim(),
                Name = ws.Cells[row, 2].Text.Trim(),
                LastName = ws.Cells[row, 3].Text.Trim(),
                BirthDate = DateOnly.Parse(ws.Cells[row, 4].Text.Trim()),
                Address = ws.Cells[row, 5].Text.Trim(),
                Phone = ws.Cells[row, 6].Text.Trim(),
                Email = ws.Cells[row, 7].Text.Trim(),
                Charge = ws.Cells[row, 8].Text.Trim(),
                Salary = double.Parse(ws.Cells[row, 9].Text.Trim(), CultureInfo.InvariantCulture),
                StartDate = DateOnly.Parse(ws.Cells[row, 10].Text.Trim()),
                Status = ws.Cells[row, 11].Text.Trim(),
                EducationLevel = ws.Cells[row, 12].Text.Trim(),
                ProfessionalPorfile = ws.Cells[row, 13].Text.Trim(),
                DepartmentId = department.Id
            };

            await _employeeService.CreateAsync(dto);
            imported.Add(dto);
        }

        return imported;
    }
}
