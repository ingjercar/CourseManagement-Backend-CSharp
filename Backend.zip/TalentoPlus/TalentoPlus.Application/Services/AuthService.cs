// TalentoPlus.Application/Services/AuthService.cs
using BCrypt.Net;
using TalentoPlus.Application.Interfaces;
using TalentoPlus.Domain.Entities;
using TalentoPlus.Domain.IRepositories;

namespace TalentoPlus.Application.Services;

public interface IAuthService
{
    Task<Employee?> RegisterAsync(Employee employee, string password);
    Task<(Employee? employee, bool success)> ValidateCredentialsAsync(string document, string email, string password);
    Task LogoutAsync(Employee employee);
}

public class AuthService : IAuthService
{
    private readonly IEmployeeRepository _repo;

    public AuthService(IEmployeeRepository repo)
    {
        _repo = repo;
    }

    public async Task<Employee?> RegisterAsync(Employee employee, string password)
    {
        // Evitar duplicados por documento o email
        var byDoc = await _repo.GetByDocumentAsync(employee.Document);
        if (byDoc != null) return null;

        // Hash password
        employee.PasswordHash = BCrypt.Net.BCrypt.HashPassword(password);
        await _repo.AddAsync(employee);
        await _repo.SaveChangesAsync();
        return employee;
    }

    public async Task<(Employee? employee, bool success)> ValidateCredentialsAsync(string document, string email, string password)
    {
        // Intentamos buscar por documento + email
        var emp = (await _repo.GetAllAsync())
            .FirstOrDefault(e => e.Document == document && e.Email == email);

        if (emp == null) return (null, false);
        var ok = BCrypt.Net.BCrypt.Verify(password, emp.PasswordHash);
        return (emp, ok);
    }

    public async Task LogoutAsync(Employee employee)
    {
        // Si usas refresh tokens: limpiarlo
        employee.RefreshToken = null;
        employee.RefreshTokenExpiry = null;
        _repo.Update(employee);
        await _repo.SaveChangesAsync();
    }
}