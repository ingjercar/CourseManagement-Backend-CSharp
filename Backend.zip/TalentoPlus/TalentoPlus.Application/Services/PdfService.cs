// TalentoPlus.Application/Services/PdfService.cs
using QuestPDF.Fluent;
using QuestPDF.Helpers;
using QuestPDF.Infrastructure;
using TalentoPlus.Domain.Entities;

public interface IPdfService
{
    byte[] GenerateResume(Employee e);
}

public class PdfService : IPdfService
{
    public byte[] GenerateResume(Employee e)
    {
        var doc = Document.Create(container =>
        {
            container.Page(page =>
            {
                page.Size(PageSizes.A4);
                page.Margin(30);
                page.PageColor(Colors.White);
                page.DefaultTextStyle(x => x.FontSize(12));

                page.Header()
                    .Row(row =>
                    {
                        row.RelativeColumn().Column(c =>
                        {
                            c.Item().Text($"{e.Name} {e.LastName}").Bold().FontSize(20);
                            c.Item().Text($"Documento: {e.Document}");
                            c.Item().Text($"Email: {e.Email}");
                            c.Item().Text($"Teléfono: {e.Phone}");
                        });
                    });

                page.Content().PaddingVertical(10).Column(col =>
                {
                    col.Spacing(5);
                    col.Item().Text("Perfil profesional").Bold();
                    col.Item().Text(e.ProfessionalPorfile ?? "");
                    col.Item().Text("Educación").Bold();
                    col.Item().Text(e.EducationLevel ?? "");
                    col.Item().Text("Cargo").Bold();
                    col.Item().Text(e.Charge ?? "");
                    col.Item().Text("Departamento").Bold();
                    col.Item().Text(e.Department?.Name ?? "");
                    // Otros campos
                });

                page.Footer().AlignCenter().Text(x => x.Span("TalentoPlus - Hoja de vida"));
            });
        });

        using var ms = new MemoryStream();
        doc.GeneratePdf(ms);
        return ms.ToArray();
    }
}
