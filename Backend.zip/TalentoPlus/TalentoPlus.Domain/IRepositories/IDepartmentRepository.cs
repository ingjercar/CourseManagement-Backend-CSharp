// TalentoPlus.Domain/Interfaces/IDepartmentRepository.cs
using TalentoPlus.Domain.Entities;

namespace TalentoPlus.Domain.IRepositories;

public interface IDepartmentRepository : IRepository<Department>
{
    Task<Department?> GetByNameAsync(string name);
}