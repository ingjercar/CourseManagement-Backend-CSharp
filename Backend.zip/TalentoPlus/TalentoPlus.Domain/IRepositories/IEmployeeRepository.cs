using TalentoPlus.Domain.Entities;

namespace TalentoPlus.Domain.IRepositories;

public interface IEmployeeRepository : IRepository<Employee>
{
    Task<Employee?> GetByDocumentAsync(string document);
}