// TalentoPlus.Domain/Entities/Employee.cs
using System.ComponentModel.DataAnnotations.Schema;

namespace TalentoPlus.Domain.Entities;

public class Employee
{
    public int Id { get; set; }
    public string Document { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string LastName { get; set; } = string.Empty;
    public DateOnly BirthDate { get; set; }
    public string Address { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string Phone { get; set; } = string.Empty;
    public string Charge { get; set; } = string.Empty;
    public double Salary { get; set; }
    public DateOnly StartDate { get; set; }
    public string Status { get; set; } = string.Empty;
    public string ProfessionalPorfile { get; set; } = string.Empty;
    public string EducationLevel { get; set; } = string.Empty;

    // Auth fields (employee acts as user)
    public string PasswordHash { get; set; } = string.Empty;
    public string? RefreshToken { get; set; }
    public DateTime? RefreshTokenExpiry { get; set; }

    public int DepartmentId { get; set; }
    [ForeignKey("DepartmentId")]
    public Department Department { get; set; } = null!;
}