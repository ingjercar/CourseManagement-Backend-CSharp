namespace TalentoPlus.Domain.Entities;

public class Department
{
    public int Id { get; set; }
    public string Name { get; set; } //= ["Recursos Humanos","Ventas","Logística","Marketing","Contabilidad","Operaciones", "Tecnología"]

    public List<Employee> Employees = new List<Employee>();

}