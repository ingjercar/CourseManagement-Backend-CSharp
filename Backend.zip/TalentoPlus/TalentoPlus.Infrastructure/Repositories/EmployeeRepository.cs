using Microsoft.EntityFrameworkCore;
using TalentoPlus.Domain.Entities;
using TalentoPlus.Domain.IRepositories;
using TalentoPlus.Infrastructure.Data;

namespace TalentoPlus.Infrastructure.Repositories;

public class EmployeeRepository : Repository<Employee>, IEmployeeRepository
{
    public EmployeeRepository(AppDbContext context) : base(context) {}

    public async Task<Employee?> GetByDocumentAsync(string document) =>
        await _context.Employees.FirstOrDefaultAsync(x => x.Document == document);
}