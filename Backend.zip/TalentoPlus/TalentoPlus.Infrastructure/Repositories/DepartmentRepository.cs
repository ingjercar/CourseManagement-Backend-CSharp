// TalentoPlus.Infrastructure/Repositories/DepartmentRepository.cs
using Microsoft.EntityFrameworkCore;
using TalentoPlus.Domain.Entities;
using TalentoPlus.Domain.IRepositories;
using TalentoPlus.Infrastructure.Data;

namespace TalentoPlus.Infrastructure.Repositories;

public class DepartmentRepository : Repository<Department>, IDepartmentRepository
{
    public DepartmentRepository(AppDbContext context) : base(context) {}

    public async Task<Department?> GetByNameAsync(string name) =>
        await _context.Departments.FirstOrDefaultAsync(d => d.Name == name);
}