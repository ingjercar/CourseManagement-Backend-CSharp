using CourseManagement.Application.DTOs;
using CourseManagement.Application.Services;
using CourseManagement.Domain.Entities;
using CourseManagement.Domain.Repositories;

namespace CourseManagement.Application.Services;

public class CourseService : ICourseService
{
    private readonly ICourseRepository _courseRepository;
    private readonly ILessonRepository _lessonRepository;

    public CourseService(ICourseRepository courseRepository, ILessonRepository lessonRepository)
    {
        _courseRepository = courseRepository;
        _lessonRepository = lessonRepository;
    }

    public async Task<CourseDetailDto?> GetByIdAsync(Guid id)
    {
        var course = await _courseRepository.GetByIdWithLessonsAsync(id);
        if (course == null) return null;

        return MapToDetailDto(course);
    }

    public async Task<CourseSummaryDto?> GetSummaryAsync(Guid id)
    {
        var course = await _courseRepository.GetByIdWithLessonsAsync(id);
        if (course == null) return null;

        return new CourseSummaryDto
        {
            Id = course.Id,
            Title = course.Title,
            Status = course.Status.ToString(),
            TotalLessons = course.Lessons.Count(l => !l.IsDeleted),
            LastModified = course.UpdatedAt
        };
    }

    public async Task<CourseSearchResultDto> SearchAsync(string? searchTerm, CourseStatus? status, int page, int pageSize)
    {
        var (courses, totalCount) = await _courseRepository.SearchAsync(searchTerm, status, page, pageSize);

        if (page < 1) page = 1;
        if (pageSize < 1) pageSize = 10;
        
        var totalPages = (int)Math.Ceiling(totalCount / (double)pageSize);

        return new CourseSearchResultDto
        {
            Courses = courses.Select(MapToDto).ToList(),
            TotalCount = totalCount,
            Page = page,
            PageSize = pageSize,
            TotalPages = totalPages
        };
    }

    public async Task<CourseDetailDto> CreateAsync(CreateCourseDto createDto)
    {
        var course = new Course
        {
            Title = createDto.Title,
        };

        var createdCourse = await _courseRepository.AddAsync(course);
        return MapToDetailDto(createdCourse);
    }

    public async Task<CourseDetailDto> UpdateAsync(Guid id, UpdateCourseDto updateDto)
    {
        var course = await _courseRepository.GetByIdAsync(id);
        if (course == null)
            throw new InvalidOperationException($"Course with ID {id} not found");

        course.Title = updateDto.Title;
        course.UpdatedAt = DateTime.UtcNow;

        await _courseRepository.UpdateAsync(course);
        return MapToDetailDto(course);
    }

    public async Task DeleteAsync(Guid id)
    {
        var course = await _courseRepository.GetByIdAsync(id);
        if (course == null)
            throw new InvalidOperationException($"Course with ID {id} not found");

        course.SoftDelete();
        await _courseRepository.DeleteAsync(course);
    }

    public async Task PublishAsync(Guid id)
    {
        var course = await _courseRepository.GetByIdWithLessonsAsync(id);
        if (course == null)
            throw new InvalidOperationException($"Course with ID {id} not found");

        try
        {
            course.Publish();
        }
        catch (InvalidOperationException ex)
        {
            // Rethrow or wrap in a domain-specific exception
            throw new InvalidOperationException(ex.Message);
        }

        await _courseRepository.UpdateAsync(course);
    }

    public async Task UnpublishAsync(Guid id)
    {
        var course = await _courseRepository.GetByIdAsync(id);
        if (course == null)
            throw new InvalidOperationException($"Course with ID {id} not found");

        course.Unpublish();
        await _courseRepository.UpdateAsync(course);
    }

    private static CourseDto MapToDto(Course course)
    {
        return new CourseDto
        {
            Id = course.Id,
            Title = course.Title,
            Status = course.Status.ToString(),
            CreatedAt = course.CreatedAt,
            UpdatedAt = course.UpdatedAt,
            LessonCount = course.Lessons.Count(l => !l.IsDeleted)
        };
    }

    private static CourseDetailDto MapToDetailDto(Course course)
    {
        return new CourseDetailDto
        {
            Id = course.Id,
            Title = course.Title,
            Status = course.Status.ToString(),
            CreatedAt = course.CreatedAt,
            UpdatedAt = course.UpdatedAt,
            Lessons = course.Lessons
                .Where(l => !l.IsDeleted)
                .OrderBy(l => l.Order)
                .Select(l => new LessonDto
                {
                    Id = l.Id,
                    CourseId = l.CourseId,
                    Title = l.Title,
                    Order = l.Order,
                    CreatedAt = l.CreatedAt,
                    UpdatedAt = l.UpdatedAt
                }).ToList()
        };
    }
}
