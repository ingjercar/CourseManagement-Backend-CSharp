using CourseManagement.Application.DTOs;
using CourseManagement.Domain.Entities;

namespace CourseManagement.Application.Services;

public interface ICourseService
{
    Task<CourseDetailDto?> GetByIdAsync(Guid id);
    Task<CourseSearchResultDto> SearchAsync(string? searchTerm, CourseStatus? status, int page, int pageSize);
    Task<CourseSummaryDto?> GetSummaryAsync(Guid id);
    Task<CourseDetailDto> CreateAsync(CreateCourseDto createDto);
    Task<CourseDetailDto> UpdateAsync(Guid id, UpdateCourseDto updateDto);
    Task DeleteAsync(Guid id);
    Task PublishAsync(Guid id);
    Task UnpublishAsync(Guid id);
}
