using CourseManagement.Application.DTOs;

namespace CourseManagement.Application.Services;

public interface ILessonService
{
    Task<LessonDto?> GetByIdAsync(Guid id);
    Task<IEnumerable<LessonDto>> GetByCourseIdAsync(Guid courseId);
    Task<LessonDto> CreateAsync(CreateLessonDto createDto);
    Task<LessonDto> UpdateAsync(Guid id, UpdateLessonDto updateDto);
    Task DeleteAsync(Guid id);
    Task ReorderAsync(Guid courseId, Guid lessonId, string direction);
}
