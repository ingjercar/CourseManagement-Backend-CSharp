using CourseManagement.Application.DTOs;
using CourseManagement.Domain.Entities;
using CourseManagement.Domain.Repositories;

namespace CourseManagement.Application.Services;

public class LessonService : ILessonService
{
    private readonly ILessonRepository _lessonRepository;
    private readonly ICourseRepository _courseRepository;

    public LessonService(ILessonRepository lessonRepository, ICourseRepository courseRepository)
    {
        _lessonRepository = lessonRepository;
        _courseRepository = courseRepository;
    }

    public async Task<LessonDto?> GetByIdAsync(Guid id)
    {
        var lesson = await _lessonRepository.GetByIdAsync(id);
        if (lesson == null) return null;

        return MapToDto(lesson);
    }

    public async Task<IEnumerable<LessonDto>> GetByCourseIdAsync(Guid courseId)
    {
        var lessons = await _lessonRepository.GetByCourseIdAsync(courseId);
        return lessons.Select(MapToDto);
    }

    public async Task<LessonDto> CreateAsync(CreateLessonDto createDto)
    {
        // Check if course exists
        if (!await _courseRepository.ExistsAsync(createDto.CourseId))
        {
            throw new InvalidOperationException($"Course with ID {createDto.CourseId} not found");
        }

        // Validate unique order
        if (await _lessonRepository.ExistsWithOrderAsync(createDto.CourseId, createDto.Order))
        {
            throw new InvalidOperationException($"A lesson with order {createDto.Order} already exists in this course");
        }

        var lesson = new Lesson
        {
            CourseId = createDto.CourseId,
            Title = createDto.Title,
            Order = createDto.Order
        };

        var createdLesson = await _lessonRepository.AddAsync(lesson);
        
        // Update course timestamp
        var course = await _courseRepository.GetByIdAsync(createDto.CourseId);
        if (course != null)
        {
            course.UpdatedAt = DateTime.UtcNow;
            await _courseRepository.UpdateAsync(course);
        }

        return MapToDto(createdLesson);
    }

    public async Task<LessonDto> UpdateAsync(Guid id, UpdateLessonDto updateDto)
    {
        var lesson = await _lessonRepository.GetByIdAsync(id);
        if (lesson == null)
            throw new InvalidOperationException($"Lesson with ID {id} not found");

        // If order is changing, validate uniqueness
        if (lesson.Order != updateDto.Order)
        {
            if (await _lessonRepository.ExistsWithOrderAsync(lesson.CourseId, updateDto.Order, lesson.Id))
            {
                throw new InvalidOperationException($"A lesson with order {updateDto.Order} already exists in this course");
            }
        }

        lesson.Title = updateDto.Title;
        lesson.Order = updateDto.Order; // Use UpdateOrder method if specific logic is needed
        lesson.UpdatedAt = DateTime.UtcNow;

        await _lessonRepository.UpdateAsync(lesson);
        return MapToDto(lesson);
    }

    public async Task DeleteAsync(Guid id)
    {
        var lesson = await _lessonRepository.GetByIdAsync(id);
        if (lesson == null)
            throw new InvalidOperationException($"Lesson with ID {id} not found");

        lesson.SoftDelete();
        await _lessonRepository.DeleteAsync(lesson);
        
        // Update course timestamp
        var course = await _courseRepository.GetByIdAsync(lesson.CourseId);
        if (course != null)
        {
            course.UpdatedAt = DateTime.UtcNow;
            await _courseRepository.UpdateAsync(course);
        }
    }

    public async Task ReorderAsync(Guid courseId, Guid lessonId, string direction)
    {
        var lesson = await _lessonRepository.GetByIdAsync(lessonId);
        if (lesson == null || lesson.CourseId != courseId)
            throw new InvalidOperationException("Lesson not found in the specified course");

        var allLessons = (await _lessonRepository.GetByCourseIdAsync(courseId)).ToList();
        var currentIndex = allLessons.FindIndex(l => l.Id == lessonId);

        if (currentIndex == -1) return;

        Lesson? targetLesson = null;

        if (direction.ToLower() == "up" && currentIndex > 0)
        {
            targetLesson = allLessons[currentIndex - 1];
        }
        else if (direction.ToLower() == "down" && currentIndex < allLessons.Count - 1)
        {
            targetLesson = allLessons[currentIndex + 1];
        }

        if (targetLesson != null)
        {
            // Swap orders
            int currentOrder = lesson.Order;
            int targetOrder = targetLesson.Order;

            lesson.UpdateOrder(targetOrder);
            targetLesson.UpdateOrder(currentOrder);

            await _lessonRepository.UpdateAsync(lesson);
            await _lessonRepository.UpdateAsync(targetLesson);
        }
    }

    private static LessonDto MapToDto(Lesson lesson)
    {
        return new LessonDto
        {
            Id = lesson.Id,
            CourseId = lesson.CourseId,
            Title = lesson.Title,
            Order = lesson.Order,
            CreatedAt = lesson.CreatedAt,
            UpdatedAt = lesson.UpdatedAt
        };
    }
}
